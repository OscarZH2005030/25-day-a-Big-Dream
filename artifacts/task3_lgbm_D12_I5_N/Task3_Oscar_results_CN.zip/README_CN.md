# Oscar Task3 LightGBM 结果包（中文）

详细表格报告见 `docs/TASK3_Oscar_LightGBM_报告_CN.md`。本包包含 D12_I5_N LightGBM 权重、训练配置/历史统计、Task1 时间留出指标、Task3 公开验证预测及逐 regime 本地代理指标、特征重要性和代码。

Task1 留出：直接 LightGBM S_state=0.934785，插值=0.909445，历史均值=0.573799。Task3 本地代理：S_FD=0.992333、拓扑 S_LWR=0、组合 S_physics=0.330778。

仅覆盖一个走廊。公开数据缺少官方 LWR 边界通量，本地 LWR/physics 仅为代理诊断，非 Kaggle 官方分数。